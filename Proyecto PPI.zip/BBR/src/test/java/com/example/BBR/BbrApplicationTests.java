package com.example.BBR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BbrApplicationTests {

	@Test
	void contextLoads() {
	}

}
